# html5admin
Sorry, but HTML5 Admin is a discontinued project.

Please check http://html5admin.com to get the new (premium) version.
